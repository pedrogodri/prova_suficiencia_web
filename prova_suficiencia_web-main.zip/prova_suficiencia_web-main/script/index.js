let paginaAtual = 1;
const itemsPorPagina = 10;

document.getElementById('formFotos').addEventListener('submit', function(event) {
    event.preventDefault();
    let albumId = parseInt(document.getElementById('albumId').value);
    let title = document.getElementById('title').value;
    let url = document.getElementById('url').value;
    let thumbnailUrl = document.getElementById('thumbnailUrl').value;
    let photos = JSON.parse(localStorage.getItem('photos')) || [];

    let newId = photos.length > 0 ? Math.max(...photos.map(p => p.id)) + 1 : 1;
    let newPhoto = { albumId, id: newId, title, url, thumbnailUrl };

    photos.push(newPhoto);
    localStorage.setItem('photos', JSON.stringify(photos));
    alert('Foto adicionada com sucesso!');
    document.getElementById('formFotos').reset();
});

function getFotos() {
    fetch('https://jsonplaceholder.typicode.com/photos')
        .then(res => res.json())
        .then(data => {
            let photos = JSON.parse(localStorage.getItem('photos')) || [];
            let novasFotos = data.filter(photo => !photos.some(p => p.id === photo.id));

            if (novasFotos.length) {
                localStorage.setItem('photos', JSON.stringify([...photos, ...novasFotos]));
                alert(`${novasFotos.length} novas fotos adicionadas!`);
            } else {
                alert('Nenhuma nova foto encontrada.');
            }
            carregarFotos();
        })
        .catch(console.error);
}

function carregarFotos() {
    let fotos = JSON.parse(localStorage.getItem('photos')) || [];
    fotos.reverse();
    atualizarTabela(fotos);
}

function atualizarTabela(fotos) {
    let corpoPagina = document.getElementById('photoTable');
    corpoPagina.innerHTML = '';

    let inicio = (paginaAtual - 1) * itemsPorPagina;
    let fim = inicio + itemsPorPagina;
    let fotosPaginadas = fotos.slice(inicio, fim);

    fotosPaginadas.forEach(foto => {
        let row = `<tr>
            <td>${foto.albumId}</td>
            <td>${foto.id}</td>
            <td>${foto.title}</td>
            <td><img src="${foto.url}" width="50"></td>
            <td><img src="${foto.thumbnailUrl}" width="50"></td>
        </tr>`;
        corpoPagina.innerHTML += row;
    });

    document.getElementById('numeroPagina').innerText = paginaAtual;
}

function trocarPagina(direcao) {
    let fotos = JSON.parse(localStorage.getItem('photos')) || [];
    let paginasTotais = Math.ceil(fotos.length / itemsPorPagina);
    if (paginaAtual + direcao > 0 && paginaAtual + direcao <= paginasTotais) {
        paginaAtual += direcao;
        carregarFotos();
    }
}

function excluirFoto() {
    let id = parseInt(document.getElementById('excluirId').value);
    let fotos = JSON.parse(localStorage.getItem('photos')) || [];
    let fotosFiltrada = fotos.filter(foto => foto.id !== id);
    localStorage.setItem('photos', JSON.stringify(fotosFiltrada));
    alert('Foto excluída!');
    document.getElementById('excluirId').value = '';
    carregarFotos();
}

function pesquisarFotos() {
    let termo = document.getElementById('searchInput').value.toLowerCase();
    let fotos = JSON.parse(localStorage.getItem('photos')) || [];

    let fotosFiltradas = fotos.filter(foto => 
        foto.id.toString().includes(termo) || 
        foto.title.toLowerCase().includes(termo)
    );

    atualizarTabela(fotosFiltradas);
}

function mostrarSecoes(section) {
    document.getElementById('cadastrar').classList.add('d-none');
    document.getElementById('listar').classList.add('d-none');
    document.getElementById('delete').classList.add('d-none');
    document.getElementById(section).classList.remove('d-none');

    // Seleciona todas as tags <a> da navbar e remove a classe active-section
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.classList.remove('active-section');
    });

    // Adiciona a classe active-section à tag <a> correspondente
    const activeLink = Array.from(navLinks).find(link => link.getAttribute('onclick').includes(section));
    if (activeLink) {
        activeLink.classList.add('active-section');
    }

    if (section === 'listar') carregarFotos();
}